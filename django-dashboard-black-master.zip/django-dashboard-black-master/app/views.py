# -*- encoding: utf-8 -*-
"""
Copyright (c) 2019 - present AppSeed.us
"""

from django.contrib.auth.decorators import login_required
from django.shortcuts import render, get_object_or_404, redirect
from django.template import loader
from django.http import HttpResponse
from django import template
from django.views.generic import TemplateView
from .models import Country


def  get(request):
    res=Country.objects.all()
    print('res:', res)
    return render(request, 'layouts/base.html', {"res": res})


class ChartView(TemplateView):
    template_name='test.html'

    def get_context_data(self,**kwargs):
        context=super().get_context_data(**kwargs)
        context["qs"]=Country.objects.all()
        print('context["qs"]:',context["qs"])

        return context






















@login_required(login_url="/login/")
def index(request):
    
    context = {}
    context['segment'] = 'index'

    html_template = loader.get_template( 'index.html' )
    return HttpResponse(html_template.render(context, request))


def pages(request):
    context = {}
    # All resource paths end in .html.
    # Pick out the html file name from the url. And load that template.
    try:
        
        load_template      = request.path.split('/')[-1]
        context['segment'] = load_template
        
        html_template = loader.get_template( load_template )
        return HttpResponse(html_template.render(context, request))
        
    except template.TemplateDoesNotExist:

        html_template = loader.get_template( 'page-404.html' )
        return HttpResponse(html_template.render(context, request))

    except:
    
        #html_template = loader.get_template( 'page-500.html' )
        #return HttpResponse(html_template.render(context, request))
        pass
